library(testthat)
library(sdmApp)

test_check("sdmApp")
