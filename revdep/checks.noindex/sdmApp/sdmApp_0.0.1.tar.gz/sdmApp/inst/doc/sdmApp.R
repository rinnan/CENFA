## ----eval=FALSE---------------------------------------------------------------
#  remotes::install_github("Abson-dev/sdmApp", dependencies = TRUE)
#  

## ----eval=FALSE---------------------------------------------------------------
#  # loading the package
#  library(sdmApp)

## ----eval=FALSE---------------------------------------------------------------
#  # Graphical User Interface (GUI)
#  sdmApp()

